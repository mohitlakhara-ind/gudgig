import mongoose from 'mongoose';

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI, {
      // Connection-level timeouts to avoid long hangs on degraded networks
      serverSelectionTimeoutMS: 15000, // 15s to find a server
      socketTimeoutMS: 45000 // 45s I/O inactivity timeout
      // Removed keepAlive and keepAliveInitialDelay (unsupported)
    });

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);

    // Handle connection events
    mongoose.connection.on('connected', () => {
      console.log('📊 Mongoose connected to MongoDB');
    });

    mongoose.connection.on('error', (err) => {
      console.error('❌ Mongoose connection error:', err);
    });

    mongoose.connection.on('disconnected', () => {
      console.log('📊 Mongoose disconnected');
    });

    // Graceful shutdown
    process.on('SIGINT', async () => {
      await mongoose.connection.close();
      console.log('📊 Mongoose connection closed due to application termination');
      process.exit(0);
    });

  } catch (error) {
    console.error('❌ Database connection error details:');
    console.error(`   Message: ${error.message}`);
    console.error(`   Code: ${error.code}`);
    console.error(`   Stack: ${error.stack}`);
    
    if (process.env.NODE_ENV === 'production') {
      console.error('💡 TIP: Check if MONGODB_URI is correctly set in your production environment variables.');
      console.error('💡 TIP: Ensure your MongoDB cluster allows connections from your production server IP.');
    }
    
    process.exit(1);
  }
};

export default connectDB;
